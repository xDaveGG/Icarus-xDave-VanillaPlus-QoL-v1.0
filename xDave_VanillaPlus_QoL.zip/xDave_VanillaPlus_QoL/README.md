# xDave VanillaPlus QoL (v1.0)

**Author:** xDave  
**Version:** 1.0  
**Type:** Override Mod (no level changes)

---

## Features

- **Stacks & Weights**
  - All item stacks doubled (×2).
  - Item weights reduced to 75% of vanilla.

- **Fuel & Energy**
  - Battery capacity increased to **10,000**.
  - Biofuel Canister (Jerrycan) capacity increased to **15,000**.
  - Rotten Meat can now be converted into Biofuel.

- **Talents**
  - *Iron Miner* talent changed to **Metal Miner** (affects all metals except Stone).
  - *Tool Durability* talent: 10% / 15% / 20%.
  - *Stoke Flames* talent: 15% / 30%.

- **Crafting**
  - Global crafting time reduced by **25%**.
  - Copper & Gold Wire output increased to **10** per craft.
  - Added **x5 bulk recipes** for common items (Epoxy, Plastic, Glass, Electronics, Steel Alloy, Concrete Mix, Bandages, Antibiotics, Ammo, Arrows).

- **Storage & Stations**
  - All chests and storage devices: **+6 slots**.
  - Crafting stations and workbenches: **48 slots**.
  - Campfires, Firepits, Stoves: **+6 slots**.
  - Tier 3 Water Purifier: **6 fill slots**.
  - Resource piles (Wood & Stone): **1000 per pile**.

- **Mounts & Saddles**
  - Starter saddles: **×2 speed and carrying capacity**.
  - All other saddles: **+5% movement speed & +5% armor** (additive).

- **Deep Ore**
  - Deep ore deposits: **+20% capacity** and **+25% mining rate**.

---

## Installation

1. Extract the folder `xDave_VanillaPlus_QoL` into your  
   ```
   ...\Icarus\Mods\
   ```
2. Open **IMM (Icarus Mod Manager)**.
3. Use **"Extract Mod from Folder"** and select the folder.
4. Enable the mod in the IMM list.
5. Click **"Install All Listed Mods"**.
6. Launch the game.

---

## Notes
- This mod contains **full override files** (not snippets), so IMM should load them without crashes.  
- If a specific device or container doesn’t match expectations, let me know – I can patch its inventory or slots directly.
